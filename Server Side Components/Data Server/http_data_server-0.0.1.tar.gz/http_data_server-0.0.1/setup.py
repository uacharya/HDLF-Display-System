import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()


setuptools.setup(
	name="http_data_server",
	version="0.0.1",
	author="Ujjwal Acharya",
	description="A HTTP server for streaming data to HDLF Display for web based visualization",
	long_description=long_description,
	long_description_content_type="text",
	url="",
	packages=setuptools.find_packages(),
	python_requires='>=2.7, <3',
	install_requires=['PIL','numpy','pywebhdfs'],
	classifiers=(
        "Programming Language :: Python :: 2.7",
        "Operating System :: OS Independent",
    	)
	)